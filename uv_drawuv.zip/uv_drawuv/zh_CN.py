data = {

    'Select Box': '框选',
    'Select Lasoo': '套索选择',
    'Draw selected in 3d_view': '绘制uv顶点',
    'Draw uv in obj_mode': '绘制uv',
    'Vertex Color': '顶点颜色',
    'Edge Color': '线框颜色',
    'Face Color': '面颜色',
    'UV Color': 'uv颜色',
    'Vertex Limit': '顶点限制',
    'AIGODLIKE Community:cupcko': '幻之境：cupcko',
    'This plugin allows for selected UV vertices to be rendered in the 3D view,and enabling the display of object UVs in object mode.': '这个插件允许在3D视图中渲染选定的UV顶点，并在物体模式下启用对象UV的显示',

}
